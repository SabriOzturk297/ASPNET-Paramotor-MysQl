﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Paramotor.Models;
using Paramotor.Models.Entities;

namespace Paramotor.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }
    ParamotordbContext db = new ParamotordbContext();

    [Route("/")]
    public IActionResult Index()
    {
        var model = new IndexViewModel(){
            Site=db.Sites!.First()
        };
        return View(model);
    }
    [Route("/About")]
    public IActionResult About()
    {
        return View();
    }
    [Route("/Service")]
    public IActionResult Service()
    {
        return View();
    }
    [Route("/Blog")]
    public IActionResult Blog()
    {
        return View();
    }
    [Route("/Contact")]
    public IActionResult Contact()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
