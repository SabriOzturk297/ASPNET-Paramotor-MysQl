using Paramotor.Models.Entities;

namespace Paramotor.Models;
public class IndexViewModel
{
    public IEnumerable<Site>? Sites { get; set; } 

    public Site? Site { get; set; }
}